// Import necessary dependencies
import React from 'react';
import './DataGrid.css';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'id', headerName: '#', width: 80 },
  { field: 'pCode', headerName: 'P_Code', width: 110 },
  { field: 'product', headerName: 'Product', width: 250 },
  { field: 'quantity', headerName: 'Quantity', width: 115,},
  { field: 'batch', headerName: 'Batch', width: 106,},
  { field: 'rate', headerName: 'Rate',  width: 95,},
  { field: 'expiryDate', headerName: 'Expiry Date',  width: 135,},
  { field: 'mrp', headerName: 'MRP',  width: 95,},
  { field: 'freeQty', headerName: 'Free Qty',  width: 120,},
  { field: 'unitDes', headerName: 'Unit Des', width: 120,},
  { field: 'bin', headerName: 'Bin', width: 90,},
  { field: 'base', headerName: 'Base',  width: 100,},
  { field: 'gst', headerName: 'GST',  width: 95,},
  { field: 'amount', headerName: 'Amount',  width: 115,},
  { field: 'schedule', headerName: 'Schedule', width: 120,},
  // { field: 'fullName', headerName: 'Full name', description: 'This column has a value getter and is not sortable.', sortable: false, width: 160,
  //   valueGetter: (params) =>
  //     `${params.row.firstName || ''} ${params.row.lastName || ''}`,
  // },
];

const rows = [
  { id: 1, pCode: "5517", product: "Celexa", quantity: 2, batch: "DLDH0006", rate: "35.00", expiryDate: "03/24", mrp: "35.00", freeQty: "-", unitDes: "Tabs", bin: "C12", base: "6.25", gst: "0.75", amount: "7.00", schedule: "-" },
  { id: 2, pCode: "14970", product: "F Safe Softgel Caps", quantity: "1", batch: "BRZ1256", rate: "159.00", expiryDate: "07/25", mrp: "159.00", freeQty: "-", unitDes: "Pack", bin: "SA-5", base: "2129.46", gst: "55.54", amount: "2385.00", schedule: "-" },
  { id: 3, pCode: "26789", product: "G 32 100’s", quantity: "9", batch: "223", rate: "170.00", expiryDate: "02/25", mrp: "170.00", freeQty: "-", unitDes: "Caps", bin: "1216", base: "121.43", gst: "14.57", amount: "136.00", schedule: "-" },
  { id: 4, pCode: "2990", product: "S Celepra 20mg", quantity: "3", batch: "G-728", rate: "130.00", expiryDate: "06/26", mrp: "130.00", freeQty: "-", unitDes: "Tabs", bin: "1243", base: "6.96", gst: "0.84", amount: "7.80", schedule: "-" },
  { id: 5, pCode: "18683", product: "Amlodipine 10 Mg Tablet", quantity: "5", batch: "SCDY00", rate: "143.69", expiryDate: "02/25", mrp: "143.69", freeQty: "-", unitDes: "Tab", bin: "622", base: "25.66", gst: "3.08", amount: "28.74", schedule: "-" },
  { id: 6, pCode: "29307", product: "Medi-Meclizine", quantity: "1", batch: "EAFT2301", rate: "85.00", expiryDate: "11/24", mrp: "85.00", freeQty: "-", unitDes: "Tabs", bin: "122", base: "91.07", gst: "10.93", amount: "102.00", schedule: "-" },
  { id: 7, pCode: "23464", product: "Amlodipine 10 Mg Tablet", quantity: "6", batch: "ADCL23", rate: "284.00", expiryDate: "10/24", mrp: "284.00", freeQty: "-", unitDes: "Tabs", bin: "1010", base: "202.86", gst: "24.34", amount: "227.20", schedule: "-" },
  { id: 8, pCode: "39630", product: "Medi-Meclizine", quantity: "1", batch: "SCPY0023", rate: "420.00", expiryDate: "11/24", mrp: "420.00", freeQty: "-", unitDes: "Tab", bin: "924", base: "472.12", gst: "76.88", amount: "504.00", schedule: "-" },
  { id: 9, pCode: "20258", product: "Medrox Adhesive Patch, Medicated", quantity: "6", batch: "E16hh2", rate: "77.89", expiryDate: "06/25", mrp: "77.89", freeQty: "-", unitDes: "Tabs", bin: "267", base: "90.41", gst: "10.85", amount: "101.26", schedule: "-" },
  { id: 10, pCode: "18630", product: "K Bind Powder", quantity: "8", batch: "J20098333", rate: "47.89", expiryDate: "11/26", mrp: "47.89", freeQty: "-", unitDes: "Tabs", bin: "622", base: "8.43", gst: "1.01", amount: "9.44", schedule: "-" },
  { id: 11, pCode: "214970", product: "F Safe Softgel Caps", quantity: "11", batch: "BRZ1256", rate: "159.00", expiryDate: "07/25", mrp: "159.00", freeQty: "-", unitDes: "Pack", bin: "SA-5", base: "2129.46", gst: "55.54", amount: "2385.00", schedule: "-" },
  { id: 12, pCode: "25517", product: "Celexa", quantity: 12, batch: "DLDH0006", rate: "35.00", expiryDate: "03/24", mrp: "35.00", freeQty: "-", unitDes: "Tabs", bin: "C12", base: "6.25", gst: "0.75", amount: "7.00", schedule: "-" },
  { id: 13, pCode: "22990", product: "S Celepra 20mg", quantity: "13", batch: "G-728", rate: "130.00", expiryDate: "06/26", mrp: "130.00", freeQty: "-", unitDes: "Tabs", bin: "1243", base: "6.96", gst: "0.84", amount: "7.80", schedule: "-" },
  { id: 14, pCode: "226789", product: "G 1232 100’s", quantity: "19", batch: "223", rate: "170.00", expiryDate: "02/25", mrp: "170.00", freeQty: "-", unitDes: "Caps", bin: "1216", base: "121.43", gst: "14.57", amount: "136.00", schedule: "-" },
  { id: 15, pCode: "229307", product: "Medi-Meclizine", quantity: "11", batch: "EAFT2301", rate: "85.00", expiryDate: "11/24", mrp: "85.00", freeQty: "-", unitDes: "Tabs", bin: "122", base: "91.07", gst: "10.93", amount: "102.00", schedule: "-" },
  { id: 16, pCode: "223464", product: "Amlodipine 10 Mg Tablet", quantity: "16", batch: "ADCL23", rate: "284.00", expiryDate: "10/24", mrp: "284.00", freeQty: "-", unitDes: "Tabs", bin: "1010", base: "202.86", gst: "24.34", amount: "227.20", schedule: "-" },
  { id: 17, pCode: "218683", product: "Amlodipine 10 Mg Tablet", quantity: "15", batch: "SCDY00", rate: "143.69", expiryDate: "02/25", mrp: "143.69", freeQty: "-", unitDes: "Tab", bin: "622", base: "25.66", gst: "3.08", amount: "28.74", schedule: "-" },
  { id: 18, pCode: "220258", product: "Medrox Adhesive Patch, Medicated", quantity: "16", batch: "E16hh2", rate: "77.89", expiryDate: "06/25", mrp: "77.89", freeQty: "-", unitDes: "Tabs", bin: "267", base: "90.41", gst: "10.85", amount: "101.26", schedule: "-" },
  { id: 19, pCode: "218630", product: "K Bind Powder", quantity: "81", batch: "J20098333", rate: "47.89", expiryDate: "11/26", mrp: "47.89", freeQty: "-", unitDes: "Tabs", bin: "622", base: "8.43", gst: "1.01", amount: "9.44", schedule: "-" },
  { id: 20, pCode: "239630", product: "Medi-Meclizine", quantity: "11", batch: "SCPY0023", rate: "420.00", expiryDate: "11/24", mrp: "420.00", freeQty: "-", unitDes: "Tab", bin: "924", base: "472.12", gst: "76.88", amount: "504.00", schedule: "-" },
  { id: 21, pCode: "35517", product: "Caelexa", quantity: 22, batch: "DLDH0006", rate: "35.00", expiryDate: "03/24", mrp: "35.00", freeQty: "-", unitDes: "Tabs", bin: "C12", base: "6.25", gst: "0.75", amount: "7.00", schedule: "-" },
  { id: 22, pCode: "314970", product: "FB Safees Softgel Caps", quantity: "12", batch: "BRZ1256", rate: "159.00", expiryDate: "07/25", mrp: "159.00", freeQty: "-", unitDes: "Pack", bin: "SA-5", base: "2129.46", gst: "55.54", amount: "2385.00", schedule: "-" },
  { id: 23, pCode: "326789", product: "LG 32 100’s", quantity: "29", batch: "223", rate: "170.00", expiryDate: "02/25", mrp: "170.00", freeQty: "-", unitDes: "Caps", bin: "1216", base: "121.43", gst: "14.57", amount: "136.00", schedule: "-" },
  { id: 24, pCode: "32990", product: "TES Caelepra 20mg", quantity: "23", batch: "G-728", rate: "130.00", expiryDate: "06/26", mrp: "130.00", freeQty: "-", unitDes: "Tabs", bin: "1243", base: "6.96", gst: "0.84", amount: "7.80", schedule: "-" },
  { id: 25, pCode: "318683", product: "Aamlodipine 10 Mg Tablet", quantity: "25", batch: "SCDY00", rate: "143.69", expiryDate: "02/25", mrp: "143.69", freeQty: "-", unitDes: "Tab", bin: "622", base: "25.66", gst: "3.08", amount: "28.74", schedule: "-" },
  { id: 26, pCode: "329307", product: "Meedi-Meeclizine", quantity: "12", batch: "EAFT2301", rate: "85.00", expiryDate: "11/24", mrp: "85.00", freeQty: "-", unitDes: "Tabs", bin: "122", base: "91.07", gst: "10.93", amount: "102.00", schedule: "-" },
  { id: 27, pCode: "323464", product: "Amslodipine 100 Mg Tablet", quantity: "26", batch: "ADCL23", rate: "284.00", expiryDate: "10/24", mrp: "284.00", freeQty: "-", unitDes: "Tabs", bin: "1010", base: "202.86", gst: "24.34", amount: "227.20", schedule: "-" },
  { id: 28, pCode: "339630", product: "Meedi-Meeclizine", quantity: "12", batch: "SCPY0023", rate: "420.00", expiryDate: "11/24", mrp: "420.00", freeQty: "-", unitDes: "Tab", bin: "924", base: "472.12", gst: "76.88", amount: "504.00", schedule: "-" },
  { id: 29, pCode: "320258", product: "Meedrox Adehesive Patch, Medicated", quantity: "26", batch: "E16hh2", rate: "77.89", expiryDate: "06/25", mrp: "77.89", freeQty: "-", unitDes: "Tabs", bin: "267", base: "90.41", gst: "10.85", amount: "101.26", schedule: "-" },
  { id: 30, pCode: "318630", product: "Kes Bohind Powder", quantity: "28", batch: "J20098333", rate: "47.89", expiryDate: "11/26", mrp: "47.89", freeQty: "-", unitDes: "Tabs", bin: "622", base: "8.43", gst: "1.01", amount: "9.44", schedule: "-" },
  // { id: 2, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
  // { id: 3, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
  // { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16 },
  // { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', age: "-" },
  // { id: 6, lastName: 'Melisandre', firstName: null, age: 150 },
  // { id: 7, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
  // { id: 8, lastName: 'Frances', firstName: 'Rossini', age: 36 },
  // { id: 9, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
];


// Create the main component
const MaterialComponents = () => {
  return (
    <>

      {/* Data Grid */}
      <div style={{ height: 493, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        // rowHeight={38}
        pageSizeOptions={[5, 10]}
        checkboxSelection
        disableRowSelectionOnClick
      />
    </div>
    </>
  );
};

export default MaterialComponents;
